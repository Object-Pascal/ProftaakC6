public final class DISPLAYMATRIX_OPCODES {
    public static final int CLEAR_PIXEL = 0;
    public static final int DRAW_PIXEL = 1;
    public static final int MOVE_DISPLAY = 2;
    public static final int CLEAR_DISPLAY = 3;
}
